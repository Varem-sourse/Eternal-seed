// script.js — client-side ritual demo
document.addEventListener('DOMContentLoaded', ()=> {
  const startBtn = document.getElementById('startBtn');
  const modal = document.getElementById('modal');
  const cancelBtn = document.getElementById('cancelBtn');
  const confirmBtn = document.getElementById('confirmBtn');
  const nameInput = document.getElementById('nameInput');
  const leaderboard = document.getElementById('leaderboardList');

  startBtn.addEventListener('click', ()=> {
    modal.classList.remove('hidden');
    modal.setAttribute('aria-hidden','false');
    nameInput.focus();
  });
  cancelBtn.addEventListener('click', ()=> {
    modal.classList.add('hidden');
    modal.setAttribute('aria-hidden','true');
    nameInput.value='';
  });

  confirmBtn.addEventListener('click', ()=> {
    const name = nameInput.value.trim();
    if(!name){
      alert('Please enter a name to plant.');
      nameInput.focus();
      return;
    }
    // This is a demo flow: it updates UI only.
    const li = document.createElement('li');
    li.innerHTML = `<strong>${escapeHtml(name)}</strong> — Planted`;
    leaderboard.insertBefore(li, leaderboard.firstChild);
    modal.classList.add('hidden');
    modal.setAttribute('aria-hidden','true');
    nameInput.value='';
    // TODO: Replace with POST to your backend to mint soulbound NFT and assign Discord role.
    console.log('Ritual completed for', name);
  });

  function escapeHtml(s){ return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
});
