Eternal Seed — Upload-Ready Site (Example)
------------------------------------------

This archive is a ready-to-upload static site for GitHub Pages.

Steps to publish:
1. Create a new GitHub repository (public) named `eternal-seed`
2. Upload the files from this archive to the repository root
3. In the repo, go to Settings → Pages and set Source to `main` branch and folder `/ (root)`
4. After a minute, your site will be available at:
   https://<your-github-username>.github.io/eternal-seed

Edit `index.html` to replace example links:
 - Discord invite: https://discord.gg/example
 - GitHub Pages link: https://example.github.io/eternal-seed

To connect a backend (soulbound minting / ledger / Discord role assignment), update the client to POST to your backend endpoints.

Good luck planting the first seeds ✨
